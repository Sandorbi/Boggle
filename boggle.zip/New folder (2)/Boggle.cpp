/*
 * File: Boggle.cpp
 * ----------------
 * Name: [TODO: enter name here]
 * Section: [TODO: enter section leader here]
 * This file is the main starter file for Assignment #4, Boggle.
 * [TODO: extend the documentation]
 */

#include <iostream>
#include "gboggle.h"
#include "grid.h"
#include "gwindow.h"
#include "lexicon.h"
#include "random.h"
#include "simpio.h"
#include "vector.h"
#include <cstdlib> 

using namespace std;

/* Constants */

const int BOGGLE_WINDOW_WIDTH = 650;
const int BOGGLE_WINDOW_HEIGHT = 350;

const string STANDARD_CUBES[16]  = {
    "AAEEGN", "ABBJOO", "ACHOPS", "AFFKPS",
    "AOOTTW", "CIMOTU", "DEILRX", "DELRVY",
    "DISTTY", "EEGHNW", "EEINSU", "EHRTVW",
    "EIOSST", "ELRTTY", "HIMNQU", "HLNNRZ"
};
 
const string BIG_BOGGLE_CUBES[25]  = {
    "AAAFRS", "AAEEEE", "AAFIRS", "ADENNN", "AEEEEM",
    "AEEGMU", "AEGMNN", "AFIRSY", "BJKQXZ", "CCNSTW",
    "CEIILT", "CEILPT", "CEIPST", "DDLNOR", "DDHNOT",
    "DHHLOR", "DHLNOR", "EIIITT", "EMOTTT", "ENSSSU",
    "FIPRSY", "GORRVW", "HIPRRY", "NOOTUW", "OOOTTU"
};

/* Function prototypes */

void welcome();
void giveInstructions();
void getGameParameters(Grid<char>& cubeGrid);
void prompt(string& ans, string text);
Vector<string> getClone(const string cubeArr[], int size);
void randomizeLetter(Vector<string> cubesVec, Grid<char>& cubeGrid);
void configurationInfo(string ans, int size, Grid<char>& cubeGrid);
string get16String(int size);
void shuffleCubes(const string cubeArr[], int size, Grid<char>& cubeGrid);
void displayLetters(string config, int size, Grid<char>& cubeGrid);
void getCubeStrings(int size, Grid<char>& cubeGrid);
void startGame(Grid<char>& cubeGrid);
void askForInput(string& word);
bool checkUsed(string& word, Set<string>& used);
bool checkLexicon(string& word, Lexicon lexicon);
bool checkLength(string& word);
bool checkBoard(string word, Grid<char> cubeGrid);
bool canBeFormed(string word, Grid<char>& cubeGrid, int r, int c, Grid<bool>& used);
void setToFalse(Grid<bool>& used);
void highLightCubes(Grid<char>& cubeGrid, string word, Grid<bool>& used);
void computerTurn(Set<string> humanGuessedWords, Lexicon& lexicon, Grid<char>& cubeGrid);
void findEveryWord(Set<string> humanGuessedWords, Lexicon& lexicon, Grid<char>& cubeGrid, string& currWord, Grid<bool>& used, int r, int c, Set<string>& foundWords);
void playAgain(bool& stopGame);

/* Main program */

int main() {
    GWindow gw(BOGGLE_WINDOW_WIDTH, BOGGLE_WINDOW_HEIGHT);
    bool stopGame = false;
    Grid<char> cubeGrid(5, 5);
    initGBoggle(gw);
    welcome();
    giveInstructions();
    while (!stopGame) {
        getGameParameters(cubeGrid);
        startGame(cubeGrid);
        playAgain(stopGame);
    }
    return 0;
}

/*
 * Function: welcome
 * Usage: welcome();
 * -----------------
 * Print out a cheery welcome message.
 */

void welcome() {
    cout << "Welcome!  You're about to play an intense game ";
    cout << "of mind-numbing Boggle.  The good news is that ";
    cout << "you might improve your vocabulary a bit.  The ";
    cout << "bad news is that you're probably going to lose ";
    cout << "miserably to this little dictionary-toting hunk ";
    cout << "of silicon.  If only YOU had a gig of RAM..." << endl << endl;
}

/*
 * Function: giveInstructions
 * Usage: giveInstructions();
 * --------------------------
 * Print out the instructions for the user.
 */

void giveInstructions() {
    cout << endl;
    cout << "The boggle board is a grid onto which I ";
    cout << "I will randomly distribute cubes. These ";
    cout << "6-sided cubes have letters rather than ";
    cout << "numbers on the faces, creating a grid of ";
    cout << "letters on which you try to form words. ";
    cout << "You go first, entering all the words you can ";
    cout << "find that are formed by tracing adjoining ";
    cout << "letters. Two letters adjoin if they are next ";
    cout << "to each other horizontally, vertically, or ";
    cout << "diagonally. A letter can only be used once ";
    cout << "in each word. Words must be at least four ";
    cout << "letters long and can be counted only once. ";
    cout << "You score points based on word length: a ";
    cout << "4-letter word is worth 1 point, 5-letters ";
    cout << "earn 2 points, and so on. After your puny ";
    cout << "brain is exhausted, I, the supercomputer, ";
    cout << "will find all the remaining words and double ";
    cout << "or triple your paltry score." << endl << endl;
    cout << "Hit return when you're ready...";
    getLine();
}

// [TODO: Fill in the rest of the code]

void playAgain(bool& stopGame) {
    string ans;
    prompt(ans, "Would you like to play again? Type yes or no: ");
    if (toLowerCase(ans) == "no") {
        stopGame = true;
    }
}

void getGameParameters(Grid<char>& cubeGrid) {
    string ans;
    int size;
    prompt(ans, "Would you like to play Big Boggle? ");
    if (toLowerCase(ans) == "yes") {
        drawBoard(5, 5);
        size = 25;
    }
    else {
        drawBoard(4, 4);
        size = 16;
        cubeGrid.resize(4, 4);
    }
    configurationInfo(ans, size, cubeGrid);
}

void configurationInfo(string ans, int size, Grid<char>& cubeGrid) {
    string ans2;
    string config;
    prompt(ans2, "Would you like to force a board configuration? ");
    if (toLowerCase(ans2) == "yes") {
        string config = get16String(size);
        displayLetters(config, size, cubeGrid);
    }
    else {
        string ans3;
        prompt(ans3, "Would you like to provide your own cube configuration? ");
        if (toLowerCase(ans3) == "yes") {
            getCubeStrings(size, cubeGrid);
        }
        else {
            if (toLowerCase(ans) == "yes") {
                shuffleCubes(BIG_BOGGLE_CUBES, size, cubeGrid);
            }
            else {
                shuffleCubes(STANDARD_CUBES, size, cubeGrid);
            }
        }
    }
    
}

void getCubeStrings(int size, Grid<char>& cubeGrid) {
    string input;
    Vector<string> sides;
    int counter = 1;
    cout << "Type in " << size << " strings consisting only from 6 characters" << endl;
    for (int i = 0; i < size; i++) {
        cout << "Enter the sides of a cube #" << counter << ": ";
        getline(cin, input);
        while (input.size() != 6) {
            cout << "Enter a 6 character string!" << endl;
            cout << "Enter the sides of a cube #" << counter << ": ";
            getline(cin, input);
        }
        sides.add(input);
        counter++;
    }
    randomizeLetter(sides, cubeGrid);
}

void displayLetters(string config, int size, Grid<char>& cubeGrid) {
    int index = 0;
    string letters = config.substr(0, size);
    for (int r = 0; r < cubeGrid.numRows(); r++) {
        for (int c = 0; c < cubeGrid.numCols(); c++) {
            cubeGrid[r][c] = letters[index];
            labelCube(r, c, cubeGrid[r][c]);
            index++;
        }
    }
}

string get16String(int size) {
    string input;
    cout << "Enter a string of length " << size << ": ";
    getline(cin, input);
    while (input.size() < size) {
        cout << "Given string is too short" << endl;
        cout << "Enter a string of length " << size << ": ";
        getline(cin, input);
    }
    return input;
}

void shuffleCubes (const string cubeArr[], int size, Grid<char>& cubeGrid) {
    Vector<string> cubesVec = getClone(cubeArr, size);
    int r;
    for (int i = 0; i < cubesVec.size(); i++) {
        r = randomInteger(i, cubesVec.size() - 1);
        string temp = cubesVec[i];
        cubesVec.set(i, cubesVec[r]);
        cubesVec.set(r, temp);
    }
    randomizeLetter(cubesVec, cubeGrid);
}


void randomizeLetter(Vector<string> cubesVec, Grid<char>& cubeGrid) {
    int str = 1;
    for (int r = 0; r < cubeGrid.numRows(); r++) {
        for (int c = 0; c < cubeGrid.numCols(); c++) {
            int index = randomInteger(0, 5);
            cubeGrid[r][c] = cubesVec[str - 1][index];
            labelCube(r, c, cubeGrid[r][c]);
            str++;
        }
    }
}

Vector<string> getClone(const string cubeArr[], int size) {
    Vector<string> clone;
    for (int i = 0; i < size; i++) {
        clone.add(cubeArr[i]);
    }
    return clone;
}


void prompt(string& ans, string text) {
    cout << text;
    getline(cin, ans);
    while (toLowerCase(ans) != "yes" && ans != "no") {
        cout << "Please enter YES or NO ";
        getline(cin, ans);
    }
}

void startGame(Grid<char>& cubeGrid) {
    string word;
    Set<string> used;
    Lexicon lexicon("EnglishWords.dat");
    Set<string> humanGuessedWords;
    cout << "Enter a word: ";
    getline(cin, word);
    while (!word.empty()) {
        if (checkLength(word)) {
            if (checkLexicon(word, lexicon)) {
                if (checkUsed(word, used)) {
                    if (checkBoard(word, cubeGrid)) {
                        humanGuessedWords += word;
                        recordWordForPlayer(word, HUMAN);
                    }
                }
            }
        }
        askForInput(word);
    }
    computerTurn(humanGuessedWords, lexicon, cubeGrid);
}

void computerTurn(Set<string> humanGuessedWords, Lexicon& lexicon, Grid<char>& cubeGrid) {
    Grid<bool> used(6,6);
    setToFalse(used);
    Set<string> foundWords;
    for (int i = 0; i < cubeGrid.numRows(); i++) {
        for (int j = 0; j < cubeGrid.numCols(); j++) {
            string currWord;
            currWord += cubeGrid[i][j];
            setToFalse(used);
            used[i][j] = true;
            findEveryWord(humanGuessedWords, lexicon, cubeGrid, currWord, used, i, j, foundWords);
        }
    }
}

void findEveryWord(Set<string> humanGuessedWords, Lexicon& lexicon, Grid<char>& cubeGrid, string& currWord, Grid<bool>& used, int r, int c, Set<string>& foundWords) {
    if (!lexicon.containsPrefix(currWord)) {
        return;
    }

    if (!lexicon.contains(currWord)) {
        return;
    }

    if (lexicon.contains(currWord) && !humanGuessedWords.contains(currWord) && !foundWords.contains(currWord) && currWord.length() >= 4) {
        recordWordForPlayer(currWord, COMPUTER);
        foundWords.add(currWord);
    }


    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) {
                continue;
            }
            if (cubeGrid.inBounds(r + i, c + j) && !used[r + i][c + j]) {
                used[r + i][c + j] = true;
                currWord += cubeGrid[r + i][c + j];
                findEveryWord(humanGuessedWords, lexicon, cubeGrid, currWord, used, r + i, c + j, foundWords);
                currWord.pop_back();
                used[r + i][c + j] = false;
            }
        }
    }
}

void highLightCubes(Grid<char>& cubeGrid, string word, Grid<bool>& used) {
    for (int i = 0; i < cubeGrid.numRows(); i++) {
        for (int j = 0; j < cubeGrid.numCols(); j++) {
            if (used[i][j]) {
                highlightCube(i, j, true);
            }
        }
    }
    pause(20);
    for (int i = 0; i < cubeGrid.numRows(); i++) {
        for (int j = 0; j < cubeGrid.numCols(); j++) {
            if (used[i][j]) {
                highlightCube(i, j, false);
            }
        }
    }
}

bool checkBoard(string word, Grid<char> cubeGrid) {
    Grid<bool> used(6, 6);
    setToFalse(used);
    for (int r = 0; r < cubeGrid.numRows(); r++) {
        for (int c = 0; c < cubeGrid.numCols(); c++) {
            if (cubeGrid[r][c] == word[0]) {
                used[r][c] = true;
                if (canBeFormed(word, cubeGrid, r, c, used)) {
                    highLightCubes(cubeGrid, word, used);
                    return true;
                }
            }
        }
    }
    cout << "This word can't be formed on the board" << endl;
    return false;
}


void setToFalse(Grid<bool>& used) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            used[i][j] = false;
        }
    }
}

bool canBeFormed(string word, Grid<char>& cubeGrid, int r, int c, Grid<bool>& used) {

    if (word.length() > cubeGrid.numRows() * cubeGrid.numRows()) {
        return false;
    }

    if (word.empty()) {
        return true;
    }

    if (word[0] != cubeGrid[r][c]) {
        return false;
    }

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) {
                continue;
            }
            if (cubeGrid.inBounds(r + i, c + j) && !used[r + i][c + j]) {
                used[r + i][c + j] = true;
                if (canBeFormed(word.substr(1), cubeGrid, r + i, c + j, used)) {
                    return true;
                }
                used[r + i][c + j] = false;
            }
        }

    }
    return false;
}



bool checkLength(string& word) {
    if (word.size() < 4) {
        cout << "Word has to be at least 4 characters long!" << endl;
        return false;
    }
    return true;
}

void askForInput(string& word) {
        cout << "Enter a word: ";
        getline(cin, word);
        if (word.empty()) return;
}

bool checkUsed(string& word, Set<string>& used) {
    if (used.contains(word)) {
        cout << "That word have already been used" << endl;
        return false;
    }
    used.add(word);
    return true;
}

bool checkLexicon(string& word, Lexicon lexicon) {
    if (!lexicon.contains(word)) {
        cout << "Thats not a word" << endl;
        return false;
    }
    return true;
}


